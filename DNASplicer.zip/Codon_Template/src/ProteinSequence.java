public class ProteinSequence {

    private int startCodonIndex;
    private int stopCodonIndex;

    ProteinSequence()
    {

    }

    public int getStopCodonIndex() {
        return stopCodonIndex;
    }

    public void setStopCodonIndex(int index) {
        this.stopCodonIndex = index;
    }

    public int getStartCodonIndex() {
        return startCodonIndex;
    }

    public void setStartCodonIndex(int index) {
        this.startCodonIndex = index;
    }
}
