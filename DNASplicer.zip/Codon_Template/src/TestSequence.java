import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
public class TestSequence {
    public static void main(String[] arg) {
        final String path = "src/testSequence.txt";
        readCodonSequence(path, 0);
        readCodonSequence(path, 1);
        readCodonSequence(path, 2);
    }

    private static void readCodonSequence(String path, int skip) {
        try {
            CodonSequence cseq = new CodonSequence();
            Scanner scanner = new Scanner(new File(path));
            for (int count = 0; count < skip; count++) {
                scanner.nextLine();
            }
            while (scanner.hasNext()) {
                String i = scanner.nextLine();
                cseq.addNucleotide(i);
            }
            scanner.close();

            int numCodon = cseq.findAllProteinSequences();
            System.out.println("Number of sequences: " + numCodon);
            for (int count = 0; count < numCodon; count++) {
                ProteinSequence ps = cseq.getProteinSequence(count);
                System.out.println("Sequence: " + count + " Start Codon: " + ps.getStartCodonIndex()
                        + " Stop Codon: " + ps.getStopCodonIndex());
            }
            cseq.print();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }
}
