import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class CodonSequence {

    private ArrayList<String> codonList = new ArrayList<>();
    private ArrayList<ProteinSequence> proteinSequence = new ArrayList();

    private String currentCodonString = "";

    public CodonSequence() {
    }

    public void addNucleotide(String nucleotide)
    {
        //String wholeCodon; // build a codon sequence array list which builds the codon out of the initial list
        // each char is a nucleotide
       this.currentCodonString += nucleotide;
       if(currentCodonString.length() == 3) {
           codonList.add(currentCodonString);
           this.currentCodonString = "";
       }

    }
    public int findAllProteinSequences()
    {
        int startingIndex = -1;
        ProteinSequence protein = new ProteinSequence();

        for(int index = 0; index < this.codonList.size(); ++index) {
            String codon = this.codonList.get(index);
            if (codon.equals("UUG") || codon.equals("GUG") || codon.equals("AUG")) {
                startingIndex = index;
            }
            else if ((codon.equals("UAG") || codon.equals("UAA") || codon.equals("UGA")) && startingIndex >= 0) {
                protein.setStartCodonIndex(startingIndex);
                protein.setStopCodonIndex(index);
                this.proteinSequence.add(protein);
                startingIndex= -1;
            }
            else
                System.out.println();
        }

        return this.proteinSequence.size();
    }

    ProteinSequence getProteinSequence(int whichSequence) {

        return (ProteinSequence) this.proteinSequence.get(whichSequence);
    }

    public void print()
    {

        for(String codon : codonList)
        {
            System.out.println(codon);
        }

    }
        }








